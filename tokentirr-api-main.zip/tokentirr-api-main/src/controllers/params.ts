export default {
  id: {
    in: 'path',
    example: '643bcfae-f856-42e1-9316-7a3b250029b3',
    name: 'id',
    required: true,
  },
} as const;
